STORAGE_FOLDER = "D:/D-Documents/Python/extensions/upload-files-server/src/storage"
LOGGING_FILE_PATH = "./src/actions_log.txt"

# ============================= client pages =============================
HOME_PAGE = "home-page.html"
NOT_FOUND_PAGE = "404-page.html"
